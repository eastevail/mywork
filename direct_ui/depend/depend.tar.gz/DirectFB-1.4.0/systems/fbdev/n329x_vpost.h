
#ifndef _GAL_VPOST_h
#define _GAL_VPOST_h

#include <sys/types.h>
#include <sys/ioctl.h>
#include <linux/fb.h>

//VPOST ===========================================================================================
// OSD
typedef enum {
    // All functions return -2 on "not open"
    OSD_Close=1,    // ()
    // Disables OSD and releases the buffers (??)
    // returns 0 on success

    OSD_Open,       // (cmd + color_format)
    // Opens OSD with color format
    // returns 0 on success

    OSD_Show,       // (cmd)
    // enables OSD mode
    // returns 0 on success

    OSD_Hide,       // (cmd)
    // disables OSD mode
    // returns 0 on success

    OSD_Clear,      // (cmd )
    // clear OSD buffer with color-key color
    // returns 0 on success

    OSD_Fill,      // (cmd +)
    // clear OSD buffer with assigned color
    // returns 0 on success

    OSD_FillBlock,      // (cmd+X-a
    // set OSD buffer with user color data (color data will be sent by "write()" function later
    // returns 0 on success

    OSD_SetTrans,   // (transparency{color})
    // Sets transparency color-key
    // returns 0 on success

    OSD_ClrTrans,   // (transparency{color})
    // Disable transparency color-key
    // returns 0 on success

} OSD_Command;

typedef struct osd_cmd_s {
    OSD_Command cmd;
    int x0;
    int y0;
    int x0_size;
    int y0_size;
    int color;              // color_format, color_key
} osd_cmd_t;

#define DISPLAY_MODE_YCBYCR		5
#define DISPLAY_MODE_RGB565     1
#define VIDEO_FORMAT_CHANGE		_IOW('v', 50, unsigned int)	//change video source format between RGB565 and YUV
#define IOCTL_GET_OSD_OFFSET    _IOR('v', 60, unsigned int *)
#define IOCTL_LCD_ENABLE_INT	_IO('v', 28)
#define IOCTL_LCD_DISABLE_INT	_IO('v', 29)
#define IOCTL_OSD_LOCK			_IOW('v', 62, unsigned int)
#define IOCTL_OSD_UNLOCK		_IOW('v', 63, unsigned int)
#define IOCTL_FB_LOCK			_IOW('v', 64, unsigned int)
#define IOCTL_FB_UNLOCK			_IOW('v', 65, unsigned int)
#define IOCTL_WAIT_VSYNC		_IOW('v', 67, unsigned int)	
#define IOCTL_LCD_BRIGHTNESS    _IOW('v', 27, unsigned int)     //brightness control
#define VIDEO_DISPLAY_ON		_IOW('v', 24, unsigned int)     //display on
#define VIDEO_DISPLAY_OFF		_IOW('v', 25, unsigned int)     //display off
#define OSD_SEND_CMD           	_IOW('v', 160, unsigned int *)


#endif /* _GAL_VPOST_h */
