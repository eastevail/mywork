#!/bin/sh
make clean
cmake .
make
make install
