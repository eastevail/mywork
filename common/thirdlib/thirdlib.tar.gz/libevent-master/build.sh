#!/bin/sh

INSTALL_PATH=`pwd`/../build
#export LDFLAGS="-L$INSTALL_PATH/lib -L/usr/local/arm_linux_4.2/arm-none-linux-gnueabi/lib"
#export CFLAGS="-I$INSTALL_PATH/include -I/usr/local/arm_linux_4.2/arm-linux/include -O2 -ffast-math -pipe"
#export CPPFLAGS="-I$INSTALL_PATH/include -I/usr/local/arm_linux_4.2/arm-linux/include"

#export CC=arm-linux-gcc
#export CXX=arm-linux-g++

make clean


./configure --host=arm-linux --prefix=$INSTALL_PATH
##./configure --prefix=$PREFIX --with-sysroot=$SYSDIR CC=arm_v5t_le-gcc CXX=arm_v5t_le-g++ AR=arm_v5t_le-ar RANLIB=arm_v5t_le-ranlib LD=arm_v5t_le-ld --host=arm-linux --build=i386 --enable-static --enable-fbdev --without-tools --with-gfxdrivers=none --with-tests=no --enable-x11=no --enable-sysfs=no --with-inputdrivers=tuobang

make
make install
